<?xml version="1.0" encoding="UTF-8"?>
<tileset name="smilies" tilewidth="32" tileheight="32" tilecount="16" columns="8">
 <image source="../../../../raw/smilies.png" width="256" height="64"/>
</tileset>
