<?xml version="1.0" encoding="UTF-8"?>
<tileset name="background_tiles" tilewidth="16" tileheight="16" tilecount="8" columns="8">
 <image source="../../../../raw/background_tiles.png" width="128" height="16"/>
</tileset>
