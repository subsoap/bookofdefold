local M = {}

M.secret = 777

function M.hello_world()
	print("Hello World Defold!")
end
	
return M